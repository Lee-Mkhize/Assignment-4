from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def homepage(reuest):
    return HttpResponse('<em>The Smino Blog</em>')

def aboutuspage(request):
    return HttpResponse('This is the about us page')

def indexpage(request):
    my_dict = {'inserted_text': 'The Life of Christopher Smith Jr.', 'instagram': '@Smino'}
    return render(request,'SmiYey/index.html',context=my_dict)

def showarticle(request):
    title = 'Its an article'
    author = 'Lee'
    article_text = """Lorem ipsum odor amet, consectetuer adipiscing elit. Et parturient facilisi vulputate; duis ornare rutrum et augue ligula. Praesent sit quis eleifend aliquet ridiculus tempus urna rutrum ac. Risus interdum lacus ipsum at vulputate odio posuere mi velit. Inceptos et auctor donec laoreet condimentum. Interdum finibus risus urna curae suscipit odio cubilia. Facilisi magna velit ipsum posuere porttitor suscipit inceptos vivamus. Magna nostra habitasse cursus tincidunt dictumst. Augue ligula aliquet conubia nulla mollis dictum quis enim hendrerit. Phasellus sed vitae, faucibus enim laoreet erat.

Arcu iaculis duis primis conubia venenatis fusce ex. Erat est nam fringilla tempus curabitur euismod dictumst. Imperdiet integer facilisis montes elit nostra nibh nunc arcu nam. Quis semper fames; dolor tempus velit mus ultricies sodales. Tortor efficitur gravida sollicitudin sagittis hendrerit tempor hendrerit nibh. Risus blandit elementum egestas senectus tempor tellus nibh. Natoque ipsum odio taciti conubia diam tincidunt imperdiet eros. Aneque ornare eu erat, cras feugiat platea ultricies quam. Bibendum venenatis at taciti convallis primis faucibus mauris.

Montes sit finibus dignissim interdum tristique. Etiam suscipit odio leo placerat neque. Sagittis primis mauris sem felis hendrerit platea aenean penatibus. Dapibus lacinia vulputate dictum vivamus cubilia porttitor. Taciti pretium morbi enim sapien interdum venenatis proin est interdum. Velit nunc est eget ex habitasse elit ullamcorper eu mollis. Morbi molestie mollis parturient vulputate sodales per.

Dui massa dui mauris nunc quam aptent. Pulvinar ad torquent at curae cras mattis facilisi. Sollicitudin sed placerat netus eleifend non odio netus. Elementum ipsum aliquet ut mus massa vel fames nostra. Amet nulla elit semper nostra id odio. Tempor mollis ullamcorper facilisi mattis ad suspendisse facilisi.

Turpis elementum inceptos mollis accumsan ullamcorper sodales purus. Erat cursus montes, varius sagittis massa integer. Arcu iaculis sed est mus luctus proin nullam! Maximus porttitor orci diam vel sociosqu ex mattis. Vel ligula justo facilisi cubilia libero. Mus magnis purus eu vel volutpat fusce pretium conubia. Faucibus etiam eget scelerisque ac ridiculus cras. Sapien dictum semper euismod tristique aenean odio. Nulla eu ad facilisi vestibulum ut euismod amet nullam fames. Hendrerit quis convallis massa sit tristique nisl."""

    return render(request,'SmiYey/article.html',{'title':title,'author':author,'article_text':article_text})
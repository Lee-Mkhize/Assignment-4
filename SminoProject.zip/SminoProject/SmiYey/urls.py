from django.urls import path
from .views import showarticle
from SmiYey.views import homepage,aboutuspage,indexpage

app_name = "SmiYey"

urlpatterns = [
                
                path('home',homepage),
                path('about',aboutuspage),
                path('',indexpage),
                path('',showarticle),
]

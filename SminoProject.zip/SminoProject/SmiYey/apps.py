from django.apps import AppConfig


class SmiyeyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SmiYey'
